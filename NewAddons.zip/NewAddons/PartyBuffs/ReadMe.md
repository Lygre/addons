# PartyBuffs

Shows party members buffs icons without the necesity of targetting. (Doesn't work on trust and fellow)

Uses the modified icons of FFXIView of this version: https://github.com/KenshiDRK/XiView

![partybuffs](http://i.imgur.com/lXZfZVo.jpg)
